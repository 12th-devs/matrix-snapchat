package snapapi

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strconv"
	"strings"
	"testing"
	"time"

	snapcrypto "github.com/0xzer/snapper/crypto"
	"github.com/0xzer/snapper/data/paths"
	"github.com/0xzer/snapper/protos"
)

func TestLiveLoreleiiiDecodeProbe(t *testing.T) {
	authURL := strings.TrimSpace(os.Getenv("SNAPAPI_LIVE_AUTH_URL"))
	if authURL == "" {
		t.Skip("set SNAPAPI_LIVE_AUTH_URL to probe a live Snapchat web session")
	}
	secret := strings.TrimSpace(os.Getenv("SNAPAPI_LIVE_SECRET"))
	if secret == "" {
		t.Fatal("SNAPAPI_LIVE_SECRET is required")
	}
	chatNeedle := strings.ToLower(strings.TrimSpace(os.Getenv("SNAPAPI_PROBE_CHAT")))
	if chatNeedle == "" {
		chatNeedle = "loreleiii"
	}
	chatIDOverride := strings.TrimSpace(os.Getenv("SNAPAPI_PROBE_CHAT_ID"))

	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()

	auth, err := liveAPIAuth(ctx, authURL, secret)
	if err != nil {
		t.Fatal(err)
	}
	client, err := New(Config{
		CookieString:        auth.CookieString,
		SelfUserID:          auth.SelfUserID,
		UserAgent:           auth.BrowserUserAgent,
		SnapClientUserAgent: auth.SnapClientUserAgent,
		SecChUA:             auth.SecChUA,
		SecChUAPlatform:     auth.SecChUAPlatform,
		GRPCWebUserAgent:    auth.GRPCWebUserAgent,
		MCSCOFIDsBin:        auth.MCSCOFIDsBin,
		Timeout:             30 * time.Second,
	})
	if err != nil {
		t.Fatal(err)
	}
	if err = client.Authenticate(ctx); err != nil {
		t.Fatal(err)
	}

	var target Chat
	if chatIDOverride != "" {
		target = Chat{ID: chatIDOverride, Name: chatNeedle}
	} else {
		syncResult, err := client.Sync(ctx, State{}, 100)
		if err != nil {
			t.Fatal(err)
		}
		for _, chat := range syncResult.Chats {
			if strings.Contains(strings.ToLower(chat.Name), chatNeedle) || strings.Contains(strings.ToLower(chat.ID), chatNeedle) {
				target = chat
				break
			}
		}
		if target.ID == "" {
			names := make([]string, 0, min(len(syncResult.Chats), 20))
			for _, chat := range syncResult.Chats[:min(len(syncResult.Chats), 20)] {
				names = append(names, chat.Name)
			}
			t.Fatalf("chat containing %q not found in %d chats; first names=%v", chatNeedle, len(syncResult.Chats), names)
		}
	}
	t.Logf("target chat id=%s name=%q version=%d", target.ID, target.Name, target.Version)

	conv, err := client.conversation(ctx, target.ID)
	if err != nil {
		t.Fatal(err)
	}
	var registeredKeyID []byte
	if os.Getenv("SNAPAPI_PROBE_REGISTER_EEL_KEY") == "1" {
		keyID, err := probeInitializeWebKey(ctx, client)
		if err != nil {
			t.Fatalf("initialize web key: %v", err)
		}
		registeredKeyID = keyID
		t.Logf("registered tentative web key id=%s", shortHex(keyID))
	}

	limit := 10
	if value := strings.TrimSpace(os.Getenv("SNAPAPI_PROBE_LIMIT")); value != "" {
		if parsed, parseErr := strconv.Atoi(value); parseErr == nil && parsed > 0 {
			limit = parsed
		}
	}
	messages, err := probeQueryRawMessages(ctx, client, conv.GetConversationId(), conv.GetVersion(), limit)
	if err != nil {
		t.Fatal(err)
	}
	if len(messages) == 0 {
		t.Fatal("query returned no messages")
	}
	for _, msg := range messages {
		probeDumpMessage(t, msg)
	}
	if len(registeredKeyID) > 0 {
		for _, msg := range messages {
			if msg.GetContents().GetEnvelopeEncryption().GetEelEncryption() == nil {
				continue
			}
			resp, err := probeRequestEELReEncryption(ctx, client, conv, msg, registeredKeyID)
			if err != nil {
				t.Fatalf("request eel re-encryption for message %d: %v", msg.GetMessageId(), err)
			}
			t.Logf("re-encryption request message=%d success=%v retryable=%v current_version=%d update=%T result=%v",
				msg.GetMessageId(), resp.GetSuccess(), resp.GetRetryable(), resp.GetCurrentVersion(), resp.GetUpdate(), resp.GetResult())
			if add := resp.GetAddEelReEncryptionInit(); add != nil {
				t.Logf("add reinit result count=%d", len(add.GetEelReEncryptionInits()))
			}
			if appendResult := resp.GetAppendEelReEncryptionDestination(); appendResult != nil {
				t.Logf("append result inits=%d dest=%T", len(appendResult.GetEelReEncryptionInits()), appendResult.GetEelDestinationEncryption())
			}
			break
		}
		time.Sleep(2 * time.Second)
		after, err := probeQueryRawMessages(ctx, client, conv.GetConversationId(), conv.GetVersion()+1, 10)
		if err != nil {
			t.Logf("post re-encryption query failed: %v", err)
		} else {
			t.Logf("post re-encryption query returned %d messages", len(after))
			for _, msg := range after[:min(len(after), 3)] {
				probeDumpMessage(t, msg)
			}
		}
	}
}

type liveAuthResponse struct {
	CookieString        string `json:"cookieString"`
	SelfUserID          string `json:"selfUserID"`
	BrowserUserAgent    string `json:"browserUserAgent"`
	SnapClientUserAgent string `json:"snapClientUserAgent"`
	SecChUA             string `json:"secChUa"`
	SecChUAPlatform     string `json:"secChUaPlatform"`
	GRPCWebUserAgent    string `json:"grpcWebUserAgent"`
	MCSCOFIDsBin        string `json:"mcsCofIdsBin"`
}

func liveAPIAuth(ctx context.Context, authURL, secret string) (liveAuthResponse, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, authURL, nil)
	if err != nil {
		return liveAuthResponse{}, err
	}
	req.Header.Set("X-Bridge-Secret", secret)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return liveAuthResponse{}, err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		return liveAuthResponse{}, fmt.Errorf("api-auth returned %s", resp.Status)
	}
	var auth liveAuthResponse
	if err = json.NewDecoder(resp.Body).Decode(&auth); err != nil {
		return liveAuthResponse{}, err
	}
	return auth, nil
}

func probeQueryRawMessages(ctx context.Context, client *Client, convID *protos.UUID, version int64, limit int) ([]*protos.ContentMessage, error) {
	req := &protos.QueryMessagesRequest{
		SelfUserId:         client.selfUUID(),
		ConversationId:     convID,
		RequestedCountSize: int32(limit),
		CurrentVersion:     version,
	}
	var resp protos.QueryMessagesResponse
	if err := client.doGRPC(ctx, paths.QUERY_MESSAGES, req, &resp); err != nil {
		return nil, err
	}
	return resp.GetMessages(), nil
}

func probeInitializeWebKey(ctx context.Context, client *Client) ([]byte, error) {
	tentative, _, _, err := snapcrypto.NewFideliusTentativeWebKey()
	if err != nil {
		return nil, err
	}
	req := &protos.InitializeWebKeyRequest{TentativeWebKey: tentative}
	var resp protos.InitializeWebKeyResponse
	if err = client.doGRPC(ctx, paths.INITIALIZE_WEB_KEY, req, &resp); err != nil {
		return nil, err
	}
	return tentative.GetKeyPairId(), nil
}

func probeRequestEELReEncryption(ctx context.Context, client *Client, conv *protos.Conversation, msg *protos.ContentMessage, keyID []byte) (*protos.UpdateContentMessageResponse, error) {
	req := &protos.UpdateContentMessageRequest{
		SelfUserId:         client.selfUUID(),
		ClientResolutionId: randomUint64(),
		CurrentVersion:     conv.GetVersion(),
		Update: &protos.UpdateAction{
			SenderId:        client.selfUUID(),
			MessageId:       msg.GetMessageId(),
			ConversationId:  conv.GetConversationId(),
			UpdateTimestamp: time.Now().UnixMilli(),
			Update: &protos.UpdateAction_AddEelReEncryptionInit{
				AddEelReEncryptionInit: &protos.AddEelReEncryptionInit{
					PublicKeyIdentifier: keyID,
				},
			},
		},
	}
	var resp protos.UpdateContentMessageResponse
	if err := client.doGRPC(ctx, paths.UPDATE_CONTENT_MESSAGE, req, &resp); err != nil {
		return nil, err
	}
	return &resp, nil
}

func probeDumpMessage(t *testing.T, msg *protos.ContentMessage) {
	t.Helper()
	envelope := msg.GetContents()
	if envelope == nil {
		t.Logf("message id=%d no envelope", msg.GetMessageId())
		return
	}
	t.Logf("message id=%d type=%s sender=%s server_ms=%d contents_len=%d encryption=%T",
		msg.GetMessageId(),
		envelope.GetContentType().String(),
		uuidToString(msg.GetSenderId()),
		msg.GetMetaData().GetServerCreatedAt(),
		len(envelope.GetContents()),
		envelope.GetEnvelopeEncryption().GetMethod(),
	)
	if text, ok := decodeContentsText(envelope.GetContents()); ok {
		t.Logf("message id=%d raw proto text=%q", msg.GetMessageId(), text)
	}
	if clear := envelope.GetEnvelopeEncryption().GetClearTextEelKeyEncryption(); clear != nil {
		t.Logf("message id=%d clear_eel cek=%d cek_iv=%d", msg.GetMessageId(), len(clear.GetCek()), len(clear.GetCekIv()))
		if text, ok := tryDecodeWithKey(envelope.GetContents(), clear.GetCek(), clear.GetCekIv(), nil); ok {
			t.Logf("message id=%d clear_eel decoded=%q", msg.GetMessageId(), text)
		}
	}
	if eel := envelope.GetEnvelopeEncryption().GetEelEncryption(); eel != nil {
		t.Logf("message id=%d eel cek=%d cek_iv=%d nonce=%d sender_pub=%d sender_version=%d",
			msg.GetMessageId(), len(eel.GetCek()), len(eel.GetCekIv()), len(eel.GetNonce()), len(eel.GetSenderPublicKey()), eel.GetSenderVersion())
		if os.Getenv("SNAPAPI_PROBE_VERBOSE_EEL") == "1" {
			t.Logf("message id=%d eel_b64 contents=%s cek_iv=%s nonce=%s sender_pub=%s",
				msg.GetMessageId(),
				base64.StdEncoding.EncodeToString(envelope.GetContents()),
				base64.StdEncoding.EncodeToString(eel.GetCekIv()),
				base64.StdEncoding.EncodeToString(eel.GetNonce()),
				base64.StdEncoding.EncodeToString(eel.GetSenderPublicKey()),
			)
		}
		if text, ok := tryDecodeWithKey(envelope.GetContents(), eel.GetCek(), eel.GetCekIv(), eel.GetNonce()); ok {
			t.Logf("message id=%d eel inline-cek decoded=%q", msg.GetMessageId(), text)
		}
	}
	for index, init := range msg.GetMetaData().GetEelReEncryptionInits() {
		t.Logf("message id=%d eel_reinit[%d] user=%s key_ids=%d first=%s",
			msg.GetMessageId(), index, uuidToString(init.GetUserId()), len(init.GetPublicKeyIdentifiers()), shortHex(firstBytes(init.GetPublicKeyIdentifiers())))
	}
}

func decodeContentsText(data []byte) (string, bool) {
	if len(data) == 0 {
		return "", false
	}
	var contents protos.Contents
	if err := protos.DecodeProtoMessage(data, &contents); err != nil {
		return "", false
	}
	text := strings.TrimSpace(contents.GetText().GetText())
	return text, text != ""
}

func tryDecodeWithKey(data, key, nonceA, nonceB []byte) (string, bool) {
	for _, nonce := range [][]byte{nonceA, nonceB, firstN(nonceB, 12), firstN(nonceA, 12)} {
		if text, ok := tryDecodeGCMText(data, key, nonce); ok {
			return text, true
		}
	}
	for _, iv := range [][]byte{nonceB, nonceA} {
		if text, ok := tryDecodeCBCText(data, key, iv); ok {
			return text, true
		}
	}
	return "", false
}

func tryDecodeGCMText(data, key, nonce []byte) (string, bool) {
	if len(key) != 16 && len(key) != 24 && len(key) != 32 {
		return "", false
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", false
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil || len(nonce) != gcm.NonceSize() {
		return "", false
	}
	decrypted, err := gcm.Open(nil, nonce, data, nil)
	if err != nil {
		return "", false
	}
	return decodeContentsText(decrypted)
}

func tryDecodeCBCText(data, key, iv []byte) (string, bool) {
	if decrypted, ok := decryptMediaCBC(data, key, iv); ok {
		return decodeContentsText(decrypted)
	}
	return "", false
}

func shortHex(data []byte) string {
	if len(data) == 0 {
		return ""
	}
	encoded := hex.EncodeToString(data)
	if len(encoded) > 16 {
		return encoded[:16]
	}
	return encoded
}

func firstBytes(items [][]byte) []byte {
	if len(items) == 0 {
		return nil
	}
	return items[0]
}

func firstN(data []byte, count int) []byte {
	if len(data) < count {
		return nil
	}
	return data[:count]
}
