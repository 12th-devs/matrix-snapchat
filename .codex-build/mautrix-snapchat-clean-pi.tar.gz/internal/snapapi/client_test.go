package snapapi

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"errors"
	"testing"

	"github.com/0xzer/snapper/protos"
)

func TestMessageBodyChatText(t *testing.T) {
	contentBytes, err := protos.EncodeProtoMessage(&protos.Contents{
		Content: &protos.Contents_Text{
			Text: &protos.Text{Text: "hello from api"},
		},
	})
	if err != nil {
		t.Fatal(err)
	}

	body, isSnap := (&Client{}).messageBody(context.Background(), "chat-1", &protos.ContentMessage{
		MessageId: 123,
		Contents: &protos.ContentEnvelope{
			ContentType: protos.ContentType_CHAT,
			Contents:    contentBytes,
		},
	})
	if body != "hello from api" {
		t.Fatalf("body = %q, want decoded text", body)
	}
	if isSnap {
		t.Fatal("chat text was marked as snap")
	}
}

func TestMessageBodyUndecodableChatFallsBackToNewChat(t *testing.T) {
	body, isSnap := (&Client{}).messageBody(context.Background(), "chat-1", &protos.ContentMessage{
		MessageId: 456,
		Contents: &protos.ContentEnvelope{
			ContentType: protos.ContentType_CHAT,
			Contents:    []byte{0xff, 0x01, 0x02},
		},
	})
	if body != "New Chat" {
		t.Fatalf("body = %q, want safe chat notice", body)
	}
	if isSnap {
		t.Fatal("undecodable chat was marked as snap")
	}
}

func TestMessageBodyClearTextEELChatText(t *testing.T) {
	contentBytes, err := protos.EncodeProtoMessage(&protos.Contents{
		Content: &protos.Contents_Text{
			Text: &protos.Text{Text: "hello from cleartext eel"},
		},
	})
	if err != nil {
		t.Fatal(err)
	}

	key := []byte("0123456789abcdef0123456789abcdef")
	nonce := []byte("123456789012")
	block, err := aes.NewCipher(key)
	if err != nil {
		t.Fatal(err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		t.Fatal(err)
	}
	encrypted := gcm.Seal(nil, nonce, contentBytes, nil)

	body, isSnap := (&Client{}).messageBody(context.Background(), "chat-1", &protos.ContentMessage{
		MessageId: 789,
		Contents: &protos.ContentEnvelope{
			ContentType: protos.ContentType_CHAT,
			Contents:    encrypted,
			EnvelopeEncryption: &protos.EnvelopeEncryption{
				Method: &protos.EnvelopeEncryption_ClearTextEelKeyEncryption{
					ClearTextEelKeyEncryption: &protos.ClearTextEelKeyEncryption{
						Cek:   key,
						CekIv: nonce,
					},
				},
			},
		},
	})
	if body != "hello from cleartext eel" {
		t.Fatalf("body = %q, want decoded cleartext EEL text", body)
	}
	if isSnap {
		t.Fatal("cleartext EEL chat text was marked as snap")
	}
}

type fakeEELDecrypter struct {
	output []byte
	err    error
	calls  int
}

func (f *fakeEELDecrypter) DecryptEEL(_ context.Context, _ EELDecryptRequest) ([]byte, error) {
	f.calls++
	if f.err != nil {
		return nil, f.err
	}
	return f.output, nil
}

func TestMessageBodyFullEELHelperChatText(t *testing.T) {
	contentBytes, err := protos.EncodeProtoMessage(&protos.Contents{
		Content: &protos.Contents_Text{
			Text: &protos.Text{Text: "hello from full eel"},
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	decrypter := &fakeEELDecrypter{output: contentBytes}

	body, isSnap := (&Client{eelDecrypter: decrypter}).messageBody(context.Background(), "chat-1", &protos.ContentMessage{
		MessageId: 900,
		Contents: &protos.ContentEnvelope{
			ContentType: protos.ContentType_CHAT,
			Contents:    []byte{0x01, 0x02},
			EnvelopeEncryption: &protos.EnvelopeEncryption{
				Method: &protos.EnvelopeEncryption_EelEncryption{
					EelEncryption: &protos.EelEncryption{
						CekIv:           []byte("123456789012"),
						Nonce:           []byte("abcdefghijklmnop"),
						SenderPublicKey: []byte("sender-public-key-placeholder"),
						SenderVersion:   7,
					},
				},
			},
		},
	})
	if body != "hello from full eel" {
		t.Fatalf("body = %q, want decoded full EEL text", body)
	}
	if isSnap {
		t.Fatal("full EEL chat text was marked as snap")
	}
	if decrypter.calls != 1 {
		t.Fatalf("helper calls = %d, want 1", decrypter.calls)
	}
}

func TestMessageBodyFullEELHelperFailureFallsBackToNewChat(t *testing.T) {
	decrypter := &fakeEELDecrypter{err: errors.New("key unavailable")}
	body, isSnap := (&Client{eelDecrypter: decrypter}).messageBody(context.Background(), "chat-1", &protos.ContentMessage{
		MessageId: 901,
		Contents: &protos.ContentEnvelope{
			ContentType: protos.ContentType_CHAT,
			Contents:    []byte{0x01, 0x02},
			EnvelopeEncryption: &protos.EnvelopeEncryption{
				Method: &protos.EnvelopeEncryption_EelEncryption{
					EelEncryption: &protos.EelEncryption{
						CekIv:           []byte("123456789012"),
						Nonce:           []byte("abcdefghijklmnop"),
						SenderPublicKey: []byte("sender-public-key-placeholder"),
						SenderVersion:   7,
					},
				},
			},
		},
	})
	if body != "New Chat" {
		t.Fatalf("body = %q, want safe chat notice", body)
	}
	if isSnap {
		t.Fatal("full EEL failure was marked as snap")
	}
}
