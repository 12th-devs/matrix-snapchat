package bridgev2

import (
	"testing"
	"time"

	"github.com/colej/mautrix-snapchat/internal/connector"
	"github.com/colej/mautrix-snapchat/internal/snapapi"
)

func TestBaseSnapchatMessageID(t *testing.T) {
	cases := map[string]string{
		"123":                       "123",
		"123-media-abc":             "123",
		"123-snap-unavailable":      "123",
		"123-edit-abc":              "123",
		"client-456-media-deadbeef": "client-456",
		"  789-media-abc-extra  ":   "789",
		"92639b1c-c6b9-5d4a-b894-a62951708f3b.msg.1407":    "1407",
		"92639b1c-c6b9-5d4a-b894-a62951708f3b.msg.1407-xx": "1407-xx",
	}
	for input, want := range cases {
		if got := baseSnapchatMessageID(input); got != want {
			t.Fatalf("baseSnapchatMessageID(%q) = %q, want %q", input, got, want)
		}
	}
}

func TestParseSnapchatMessageIDAcceptsHydratedIDs(t *testing.T) {
	got, ok := parseSnapchatMessageID("123-media-deadbeef")
	if !ok || got != 123 {
		t.Fatalf("parseSnapchatMessageID hydrated = %d, %t; want 123, true", got, ok)
	}
	got, ok = parseSnapchatMessageID("client-456-media-deadbeef")
	if !ok || got != 456 {
		t.Fatalf("parseSnapchatMessageID client hydrated = %d, %t; want 456, true", got, ok)
	}
	got, ok = parseSnapchatMessageID("92639b1c-c6b9-5d4a-b894-a62951708f3b.msg.1407-media-deadbeef")
	if !ok || got != 1407 {
		t.Fatalf("parseSnapchatMessageID scoped hydrated = %d, %t; want 1407, true", got, ok)
	}
}

func TestScopedSnapchatMessageIDNamespacesByChat(t *testing.T) {
	a := scopedSnapchatMessageID("chat-a", "1407")
	b := scopedSnapchatMessageID("chat-b", "1407")
	if a == b {
		t.Fatalf("scoped ids collided: %q", a)
	}
	if got := baseSnapchatMessageID(a); got != "1407" {
		t.Fatalf("baseSnapchatMessageID(scoped) = %q, want 1407", got)
	}
	if got := scopedSnapchatMessageID("chat-a", a); got != a {
		t.Fatalf("scopedSnapchatMessageID double-scoped %q into %q", a, got)
	}
}

func TestConnectorMessageFromAPIPreservesSnapNotice(t *testing.T) {
	msg := connectorMessageFromAPI(snapapi.Message{
		ID:        "123",
		AuthorID:  "emerson",
		Author:    "Emerson",
		IsSnap:    true,
		Timestamp: time.Date(2026, 5, 17, 12, 0, 0, 0, time.UTC),
	})
	if msg.Text != "New Snap" || !msg.IsSnap {
		t.Fatalf("connector message = text %q isSnap %t, want New Snap true", msg.Text, msg.IsSnap)
	}
	if msg.Timestamp == "" {
		t.Fatal("timestamp was not preserved")
	}
}

func TestNewChatPlaceholderIsVisibleText(t *testing.T) {
	if isGeneratedSnapchatNotice("New Chat") {
		t.Fatal("New Chat should be sent as visible text, not a notice")
	}
	if !isGeneratedSnapchatNotice("New Snap") {
		t.Fatal("New Snap should remain a notice placeholder")
	}
}

func TestShouldSuppressOutgoingEchoMatchesRecentBody(t *testing.T) {
	sa := &SnapchatAPI{recentOutgoing: map[string][]pendingOutgoing{}}
	sa.recordRecentOutgoing("chat-1", "hello there", "")
	if !sa.shouldSuppressOutgoingEcho("chat-1", connector.Message{
		ID:       "1485",
		Text:     "hello there",
		Outgoing: true,
	}) {
		t.Fatal("expected outgoing echo to be suppressed")
	}
	if sa.shouldSuppressOutgoingEcho("chat-1", connector.Message{
		ID:       "1486",
		Text:     "different text",
		Outgoing: true,
	}) {
		t.Fatal("unexpected suppression for non-matching body")
	}
}
